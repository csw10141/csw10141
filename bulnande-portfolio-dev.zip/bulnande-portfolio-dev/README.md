## 🔥불난데부채질 포트폴리오 페이지
### 도전과 실패, 하지만 반드시 기억해야만하는 시간들에 대한 기록을 위해

> 많은 사람들은 실패를 두려워해 아예 시작조차 않는 경우가 많다. 그러나 내가 보기엔 실패란 시도조차 하지 않는 것을 의미한다. - 마리아 나브라틸로바

### 사용스택
- 클라이언트 : React, Styled-component, Axios
- 서버 : Express.js, Sequelize, Sequeilize-cli
- DBMS : PostgreSQL

### DB diagram
![Bulbu DB diagram](https://user-images.githubusercontent.com/87600115/175210437-72f0381e-fb7e-4929-9dc3-c766ccfc3834.png)
