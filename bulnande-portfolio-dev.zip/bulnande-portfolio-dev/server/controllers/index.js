const workers = require("./worker");
const projects = require("./project");

module.exports = {
  workers,
  projects,
};
